// Dados dos usuários válidos
const validUsers = {
    'nexabyte_admin': {
        password: 'Nx@2025!Secure',
        company: 'Nexabyte Solutions'
    },
    'tecnovox_sys': {
        password: 'Tvx#Sys98!',
        company: 'TecnoVox Systems'
    },
    'cloudsphere_ti': {
        password: 'Cl0ud$ph3r3Ti!',
        company: 'Cloudsphere TI'
    },
    'inovacode_labs': {
        password: 'In0v@Code#22',
        company: 'InovaCode Labs'
    },
    'bitsafe_tec': {
        password: 'B1t$@feT3c#99',
        company: 'BitSafe Tecnologia'
    }
};

document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const errorMessage = document.createElement('div');
    errorMessage.className = 'error-message';
    errorMessage.id = 'errorMessage';
    
    const successMessage = document.createElement('div');
    successMessage.className = 'success-message';
    successMessage.id = 'successMessage';
    
    // Inserir mensagens antes do formulário
    loginForm.parentNode.insertBefore(errorMessage, loginForm);
    loginForm.parentNode.insertBefore(successMessage, loginForm);

    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        
        // Limpar mensagens anteriores
        errorMessage.style.display = 'none';
        successMessage.style.display = 'none';
        
        // Verificar se o usuário existe
        if (validUsers[username]) {
            // Verificar se a senha está correta
            if (validUsers[username].password === password) {
                // Login bem-sucedido
                successMessage.textContent = `Bem-vindo, ${validUsers[username].company}!`;
                successMessage.style.display = 'block';
                
                // Salvar dados do usuário no localStorage
                localStorage.setItem('loggedInUser', JSON.stringify({
                    username: username,
                    company: validUsers[username].company
                }));
                
                // Redirecionar para a página home após 1.5 segundos
                setTimeout(() => {
                    window.location.href = 'home.html';
                }, 1500);
            } else {
                // Senha incorreta
                errorMessage.textContent = 'Senha incorreta. Tente novamente.';
                errorMessage.style.display = 'block';
            }
        } else {
            // Usuário não encontrado
            errorMessage.textContent = 'Usuário não encontrado. Verifique o nome de usuário.';
            errorMessage.style.display = 'block';
        }
    });
    
    // Adicionar efeito de foco nos inputs
    const inputs = document.querySelectorAll('input');
    inputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.parentNode.classList.add('focused');
        });
        
        input.addEventListener('blur', function() {
            if (this.value === '') {
                this.parentNode.classList.remove('focused');
            }
        });
    });
});
