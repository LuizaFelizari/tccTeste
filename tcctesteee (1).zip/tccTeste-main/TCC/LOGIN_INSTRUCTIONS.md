# Instruções de Login - FlyOver

## Sistema de Login Implementado

O sistema de login foi implementado com sucesso! Agora, quando você clicar no botão "ENTRAR!" na página inicial, será redirecionado para uma tela de login detalhada e bem feita.

## Usuários Disponíveis

O sistema possui 5 usuários pré-cadastrados para teste:

### 1. Nexabyte Solutions
- **Login:** `nexabyte_admin`
- **Senha:** `Nx@2025!Secure`

### 2. TecnoVox Systems
- **Login:** `tecnovox_sys`
- **Senha:** `Tvx#Sys98!`

### 3. Cloudsphere TI
- **Login:** `cloudsphere_ti`
- **Senha:** `Cl0ud$ph3r3Ti!`

### 4. InovaCode Labs
- **Login:** `inovacode_labs`
- **Senha:** `In0v@Code#22`

### 5. BitSafe Tecnologia
- **Login:** `bitsafe_tec`
- **Senha:** `B1t$@feT3c#99`

## Funcionalidades Implementadas

### ✅ Tela de Login
- Design moderno e responsivo
- Validação de usuário e senha
- Mensagens de erro e sucesso
- Lista de usuários disponíveis para referência
- Redirecionamento automático após login bem-sucedido

### ✅ Carrossel de Empresas
- Localizado na página "Quero trabalhar"
- Apresenta as 5 empresas parceiras
- Navegação com botões anterior/próximo
- Auto-play com pausa no hover
- Suporte a touch/swipe em dispositivos móveis
- Design responsivo

### ✅ Fonte Times New Roman
- Aplicada em todo o projeto
- Consistência visual em todas as páginas

## Como Testar

1. Abra o arquivo `index.html` no navegador
2. Clique no botão "ENTRAR!"
3. Use qualquer um dos usuários listados acima
4. Após o login, explore a página "Quero trabalhar" para ver o carrossel
5. Teste a navegação do carrossel com os botões ou gestos de toque

## Arquivos Modificados/Criados

### Novos Arquivos:
- `login.html` - Página de login
- `login.css` - Estilos da página de login
- `login.js` - Lógica de autenticação

### Arquivos Modificados:
- `index.html` - Redirecionamento para login
- `trabalhar.html` - Adicionado carrossel de empresas
- `trabalhar.css` - Estilos do carrossel
- `java.js` - Funcionalidade do carrossel
- `contratar.css` - Fonte Times New Roman
- `empresas.css` - Fonte Times New Roman

## Características do Carrossel

- **Auto-play:** Muda automaticamente a cada 4 segundos
- **Pausa no hover:** Para quando o mouse está sobre o carrossel
- **Navegação manual:** Botões anterior/próximo
- **Touch/Swipe:** Suporte completo para dispositivos móveis
- **Responsivo:** Adapta-se a diferentes tamanhos de tela
- **Animações suaves:** Transições fluidas entre slides

O sistema está pronto para uso e todas as funcionalidades solicitadas foram implementadas com sucesso!
