# FlyOver - Plataforma de Freelancing

## 🚀 Sobre o Projeto

O FlyOver é uma plataforma que conecta empresas que precisam de soluções com profissionais freelancers qualificados. Uma ponte inteligente entre desafios reais e talentos prontos para transformar ideias em resultados.

## ✨ Funcionalidades

### Para Freelancers
- **Exploração de Projetos**: Navegue por categorias de trabalho (Desenvolvimento Web, Design, Marketing, Consultoria)
- **Cadastro Simplificado**: Processo rápido de cadastro com validação de dados
- **Interface Intuitiva**: Design moderno e responsivo para melhor experiência

### Para Empresas
- **Publicação de Projetos**: Formulário completo para descrever necessidades
- **Categorização**: Organize projetos por área de atuação
- **Gestão de Orçamento**: Defina prazos e valores de forma transparente

### Recursos Gerais
- **Design Responsivo**: Funciona perfeitamente em desktop, tablet e mobile
- **Validação de Formulários**: Validação em tempo real com feedback visual
- **Animações Suaves**: Transições e efeitos visuais para melhor UX
- **Navegação Intuitiva**: Menu lateral com navegação clara entre seções

## 🛠️ Tecnologias Utilizadas

- **HTML5**: Estrutura semântica e acessível
- **CSS3**: Design moderno com Flexbox e Grid
- **JavaScript (ES6+)**: Interatividade e validações
- **Google Fonts**: Tipografia Inter para melhor legibilidade

## 📁 Estrutura do Projeto

```
TCC/
├── index.html          # Página inicial
├── home.html           # Dashboard principal
├── trabalhar.html      # Página para freelancers
├── contratar.html      # Cadastro de freelancers
├── empresas.html       # Página para empresas
├── style.css           # Estilos da página inicial
├── home.css            # Estilos da home
├── trabalhar.css       # Estilos da página trabalhar
├── contratar.css       # Estilos da página contratar
├── empresas.css        # Estilos da página empresas
├── java.js             # Funcionalidades JavaScript
└── README.md           # Documentação do projeto
```

## 🚀 Como Usar

1. **Acesse a página inicial** (`index.html`)
2. **Clique em "ENTRAR!"** para acessar o dashboard
3. **Navegue pelas seções**:
   - **Home**: Visão geral da plataforma
   - **Quero trabalhar**: Explore oportunidades para freelancers
   - **Empresas**: Publique projetos e encontre talentos

## 🎨 Design System

### Cores
- **Primária**: #4ecdc4 (Turquesa)
- **Secundária**: #44a08d (Verde-azulado)
- **Fundo**: #000 (Preto)
- **Cards**: Gradiente #1a1a1a → #2a2a2a
- **Texto**: #fff (Branco) / #ccc (Cinza claro)

### Tipografia
- **Fonte Principal**: Inter (Google Fonts)
- **Fallback**: Times New Roman, serif

### Componentes
- **Botões**: Bordas arredondadas, efeitos hover
- **Cards**: Sombras sutis, gradientes
- **Formulários**: Validação visual, feedback em tempo real

## 📱 Responsividade

O projeto foi desenvolvido com abordagem mobile-first:
- **Desktop**: Layout em duas colunas (sidebar + main)
- **Tablet**: Adaptação do grid e espaçamentos
- **Mobile**: Layout em coluna única, menu horizontal

## 🔧 Funcionalidades JavaScript

### Validação de Formulários
- Validação em tempo real
- Feedback visual para campos inválidos
- Prevenção de envio com dados incompletos

### Interatividade
- Animações suaves em hover
- Efeitos de loading em submissões
- Notificações de sucesso/erro
- Navegação fluida entre páginas

### UX/UI
- Scroll suave
- Animações de entrada para elementos
- Estados de loading
- Feedback visual para ações

## 🚀 Melhorias Implementadas

1. **Navegação Corrigida**: Todos os links funcionando corretamente
2. **Design Moderno**: Interface atualizada com gradientes e sombras
3. **Responsividade**: Funciona perfeitamente em todos os dispositivos
4. **Validação de Formulários**: Sistema completo de validação
5. **JavaScript Funcional**: Interatividade e animações
6. **UX Melhorada**: Feedback visual e transições suaves
7. **Conteúdo Completo**: Páginas com conteúdo relevante
8. **Código Limpo**: CSS organizado e sem duplicações

## 📞 Contato

Para dúvidas ou sugestões sobre o projeto:
- **E-mail**: info@flyover.com
- **GitHub**: [Link do repositório]

---

**FlyOver** - Sobrevoando sobre a tecnologia 🚀
