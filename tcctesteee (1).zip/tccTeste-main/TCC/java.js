// FlyOver - JavaScript Functions
document.addEventListener('DOMContentLoaded', function() {
    // Initialize the application
    initializeApp();
});

function initializeApp() {
    // Add smooth scrolling
    addSmoothScrolling();
    
    // Initialize form validations
    initializeFormValidations();
    
    // Add interactive elements
    addInteractiveElements();
    
    // Initialize animations
    initializeAnimations();
    
    // Initialize carousel
    initializeCarousel();
}

// Smooth scrolling for navigation
function addSmoothScrolling() {
    const links = document.querySelectorAll('a[href^="#"]');
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });
}

// Form validation and submission
function initializeFormValidations() {
    // Project form validation
    const projectForm = document.getElementById('projectForm');
    if (projectForm) {
        projectForm.addEventListener('submit', function(e) {
            e.preventDefault();
            if (validateProjectForm()) {
                submitProjectForm();
            }
        });
    }
    
    // Registration form validation
    const registrationForm = document.querySelector('form');
    if (registrationForm && !projectForm) {
        registrationForm.addEventListener('submit', function(e) {
            e.preventDefault();
            if (validateRegistrationForm()) {
                submitRegistrationForm();
            }
        });
    }
}

function validateProjectForm() {
    const form = document.getElementById('projectForm');
    const requiredFields = form.querySelectorAll('[required]');
    let isValid = true;
    
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            showFieldError(field, 'Este campo é obrigatório');
            isValid = false;
        } else {
            clearFieldError(field);
        }
    });
    
    // Email validation
    const emailField = document.getElementById('contato');
    if (emailField && emailField.value) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(emailField.value)) {
            showFieldError(emailField, 'E-mail inválido');
            isValid = false;
        }
    }
    
    return isValid;
}

function validateRegistrationForm() {
    const form = document.querySelector('form');
    const requiredFields = form.querySelectorAll('[required]');
    let isValid = true;
    
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            showFieldError(field, 'Este campo é obrigatório');
            isValid = false;
        } else {
            clearFieldError(field);
        }
    });
    
    // Email validation
    const emailField = form.querySelector('input[type="email"]');
    if (emailField && emailField.value) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(emailField.value)) {
            showFieldError(emailField, 'E-mail inválido');
            isValid = false;
        }
    }
    
    return isValid;
}

function showFieldError(field, message) {
    clearFieldError(field);
    field.style.borderColor = '#ff6b6b';
    
    const errorDiv = document.createElement('div');
    errorDiv.className = 'field-error';
    errorDiv.textContent = message;
    errorDiv.style.color = '#ff6b6b';
    errorDiv.style.fontSize = '12px';
    errorDiv.style.marginTop = '5px';
    
    field.parentNode.appendChild(errorDiv);
}

function clearFieldError(field) {
    field.style.borderColor = '#555';
    const existingError = field.parentNode.querySelector('.field-error');
    if (existingError) {
        existingError.remove();
    }
}

function submitProjectForm() {
    const formData = {
        titulo: document.getElementById('titulo').value,
        categoria: document.getElementById('categoria').value,
        descricao: document.getElementById('descricao').value,
        prazo: document.getElementById('prazo').value,
        valor: document.getElementById('valor').value,
        contato: document.getElementById('contato').value
    };
    
    // Simulate form submission
    showLoadingState();
    
    setTimeout(() => {
        hideLoadingState();
        showSuccessMessage('Projeto publicado com sucesso! Entraremos em contato em breve.');
        document.getElementById('projectForm').reset();
    }, 2000);
}

function submitRegistrationForm() {
    const formData = {
        nome: document.querySelector('input[placeholder*="Nome"]').value,
        email: document.querySelector('input[type="email"]').value,
        telefone: document.querySelector('input[type="tel"]').value
    };
    
    // Simulate form submission
    showLoadingState();
    
    setTimeout(() => {
        hideLoadingState();
        showSuccessMessage('Cadastro realizado com sucesso! Redirecionando...');
        setTimeout(() => {
            window.location.href = 'empresas.html';
        }, 1500);
    }, 2000);
}

function showLoadingState() {
    const submitBtn = document.querySelector('.submit-btn, .btn-proximo');
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = 'Enviando...';
        submitBtn.style.opacity = '0.7';
    }
}

function hideLoadingState() {
    const submitBtn = document.querySelector('.submit-btn, .btn-proximo');
    if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.textContent = submitBtn.textContent.includes('PROJETO') ? 'PUBLICAR PROJETO' : 'PRÓXIMO';
        submitBtn.style.opacity = '1';
    }
}

function showSuccessMessage(message) {
    // Create success notification
    const notification = document.createElement('div');
    notification.className = 'success-notification';
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(45deg, #4ecdc4, #44a08d);
        color: white;
        padding: 15px 25px;
        border-radius: 10px;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        z-index: 1000;
        animation: slideIn 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 5000);
}

// Interactive elements
function addInteractiveElements() {
    // Category cards interaction
    const categoryCards = document.querySelectorAll('.category-card');
    categoryCards.forEach(card => {
        card.addEventListener('click', function() {
            // Add visual feedback
            this.style.transform = 'scale(0.95)';
            setTimeout(() => {
                this.style.transform = '';
            }, 150);
            
            // Simulate category selection
            const category = this.querySelector('h3').textContent;
            showCategoryInfo(category);
        });
    });
    
    // Google login button
    const googleBtn = document.querySelector('.btn-google');
    if (googleBtn) {
        googleBtn.addEventListener('click', function() {
            showLoadingState();
            setTimeout(() => {
                hideLoadingState();
                showSuccessMessage('Login com Google em desenvolvimento!');
            }, 1000);
        });
    }
}

function showCategoryInfo(category) {
    const message = `Categoria "${category}" selecionada! Em breve você poderá filtrar projetos por categoria.`;
    showSuccessMessage(message);
}

// Animations
function initializeAnimations() {
    // Add CSS for animations
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
        
        .category-card {
            transition: all 0.3s ease;
        }
        
        .category-card:active {
            transform: scale(0.95);
        }
        
        .btn, .menu-btn {
            transition: all 0.3s ease;
        }
        
        .btn:hover, .menu-btn:hover {
            transform: translateY(-2px);
        }
    `;
    document.head.appendChild(style);
    
    // Animate elements on scroll
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observe elements for animation
    const animatedElements = document.querySelectorAll('.category-card, .form-container, .cta-section');
    animatedElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
}

// Utility functions
function formatCurrency(value) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(value);
}

function formatDate(date) {
    return new Intl.DateTimeFormat('pt-BR').format(date);
}

// Carousel functionality
function initializeCarousel() {
    const carouselTrack = document.getElementById('carouselTrack');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    
    if (!carouselTrack || !prevBtn || !nextBtn) {
        return; // Carousel elements not found
    }
    
    let currentIndex = 0;
    const cards = carouselTrack.querySelectorAll('.company-card');
    const totalCards = cards.length;
    const cardsPerView = getCardsPerView();
    
    // Set initial position
    updateCarouselPosition();
    updateButtonStates();
    
    // Event listeners
    prevBtn.addEventListener('click', () => {
        if (currentIndex > 0) {
            currentIndex--;
            updateCarouselPosition();
            updateButtonStates();
        }
    });
    
    nextBtn.addEventListener('click', () => {
        if (currentIndex < totalCards - cardsPerView) {
            currentIndex++;
            updateCarouselPosition();
            updateButtonStates();
        }
    });
    
    // Auto-play functionality
    let autoPlayInterval;
    function startAutoPlay() {
        autoPlayInterval = setInterval(() => {
            if (currentIndex < totalCards - cardsPerView) {
                currentIndex++;
            } else {
                currentIndex = 0; // Reset to beginning
            }
            updateCarouselPosition();
            updateButtonStates();
        }, 4000); // Change slide every 4 seconds
    }
    
    function stopAutoPlay() {
        clearInterval(autoPlayInterval);
    }
    
    // Start auto-play
    startAutoPlay();
    
    // Pause auto-play on hover
    const carouselContainer = document.querySelector('.carousel-container');
    if (carouselContainer) {
        carouselContainer.addEventListener('mouseenter', stopAutoPlay);
        carouselContainer.addEventListener('mouseleave', startAutoPlay);
    }
    
    // Touch/swipe support for mobile
    let startX = 0;
    let isDragging = false;
    
    carouselTrack.addEventListener('touchstart', (e) => {
        startX = e.touches[0].clientX;
        isDragging = true;
        stopAutoPlay();
    });
    
    carouselTrack.addEventListener('touchmove', (e) => {
        if (!isDragging) return;
        e.preventDefault();
    });
    
    carouselTrack.addEventListener('touchend', (e) => {
        if (!isDragging) return;
        
        const endX = e.changedTouches[0].clientX;
        const diffX = startX - endX;
        
        if (Math.abs(diffX) > 50) { // Minimum swipe distance
            if (diffX > 0 && currentIndex < totalCards - cardsPerView) {
                // Swipe left - next
                currentIndex++;
            } else if (diffX < 0 && currentIndex > 0) {
                // Swipe right - previous
                currentIndex--;
            }
            updateCarouselPosition();
            updateButtonStates();
        }
        
        isDragging = false;
        startAutoPlay();
    });
    
    // Handle window resize
    window.addEventListener('resize', () => {
        const newCardsPerView = getCardsPerView();
        if (newCardsPerView !== cardsPerView) {
            updateCarouselPosition();
            updateButtonStates();
        }
    });
    
    function getCardsPerView() {
        const width = window.innerWidth;
        if (width < 768) return 1;
        if (width < 1024) return 2;
        return 3;
    }
    
    function updateCarouselPosition() {
        const cardWidth = cards[0].offsetWidth + 20; // Include gap
        const translateX = -currentIndex * cardWidth;
        carouselTrack.style.transform = `translateX(${translateX}px)`;
    }
    
    function updateButtonStates() {
        const cardsPerView = getCardsPerView();
        prevBtn.disabled = currentIndex === 0;
        nextBtn.disabled = currentIndex >= totalCards - cardsPerView;
    }
}

// Export functions for global use
window.FlyOver = {
    showSuccessMessage,
    formatCurrency,
    formatDate
};
